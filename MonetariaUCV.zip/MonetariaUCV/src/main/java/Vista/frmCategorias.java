/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package Vista;

public class frmCategorias extends javax.swing.JInternalFrame {

    public frmCategorias() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        btnCerrar = new javax.swing.JButton();
        btnCamping = new javax.swing.JButton();
        btnEntretenimiento = new javax.swing.JButton();
        btnDeporte = new javax.swing.JButton();
        btnMuebles = new javax.swing.JButton();
        btnSalud = new javax.swing.JButton();
        btnEducacion = new javax.swing.JButton();
        btnAhorro = new javax.swing.JButton();
        btnComida = new javax.swing.JButton();
        btnCuidadoP = new javax.swing.JButton();
        btnDeudas = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        btnCerrar3 = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 255));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("¿Qué es lo que mas priorizas?");

        btnCerrar.setBackground(new java.awt.Color(102, 255, 102));
        btnCerrar.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnCerrar.setForeground(new java.awt.Color(0, 0, 0));
        btnCerrar.setText("CONTINUAR");
        btnCerrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCerrarActionPerformed(evt);
            }
        });

        btnCamping.setBackground(new java.awt.Color(255, 153, 51));
        btnCamping.setFont(new java.awt.Font("Segoe UI", 0, 21)); // NOI18N
        btnCamping.setForeground(new java.awt.Color(0, 0, 0));
        btnCamping.setText("CAMPING");
        btnCamping.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCampingActionPerformed(evt);
            }
        });

        btnEntretenimiento.setBackground(new java.awt.Color(0, 255, 204));
        btnEntretenimiento.setFont(new java.awt.Font("Segoe UI", 0, 13)); // NOI18N
        btnEntretenimiento.setForeground(new java.awt.Color(0, 0, 0));
        btnEntretenimiento.setText("Entretenimiento");
        btnEntretenimiento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEntretenimientoActionPerformed(evt);
            }
        });

        btnDeporte.setBackground(new java.awt.Color(255, 255, 102));
        btnDeporte.setFont(new java.awt.Font("Segoe UI", 0, 23)); // NOI18N
        btnDeporte.setForeground(new java.awt.Color(0, 0, 0));
        btnDeporte.setText("DEPORTE");
        btnDeporte.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeporteActionPerformed(evt);
            }
        });

        btnMuebles.setBackground(new java.awt.Color(51, 255, 0));
        btnMuebles.setFont(new java.awt.Font("Segoe UI", 0, 22)); // NOI18N
        btnMuebles.setForeground(new java.awt.Color(0, 0, 0));
        btnMuebles.setText("MUEBLES");
        btnMuebles.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMueblesActionPerformed(evt);
            }
        });

        btnSalud.setBackground(new java.awt.Color(102, 255, 102));
        btnSalud.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        btnSalud.setForeground(new java.awt.Color(0, 0, 0));
        btnSalud.setText("SALUD");
        btnSalud.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaludActionPerformed(evt);
            }
        });

        btnEducacion.setBackground(new java.awt.Color(255, 153, 51));
        btnEducacion.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        btnEducacion.setForeground(new java.awt.Color(0, 0, 0));
        btnEducacion.setText("EDUCACIÓN");
        btnEducacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEducacionActionPerformed(evt);
            }
        });

        btnAhorro.setBackground(new java.awt.Color(255, 204, 0));
        btnAhorro.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        btnAhorro.setForeground(new java.awt.Color(0, 0, 0));
        btnAhorro.setText("AHORRO");
        btnAhorro.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAhorroActionPerformed(evt);
            }
        });

        btnComida.setBackground(new java.awt.Color(255, 102, 255));
        btnComida.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        btnComida.setText("COMIDA");
        btnComida.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnComidaActionPerformed(evt);
            }
        });

        btnCuidadoP.setBackground(new java.awt.Color(0, 255, 204));
        btnCuidadoP.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        btnCuidadoP.setForeground(new java.awt.Color(0, 0, 0));
        btnCuidadoP.setText("CUIDADO PERSONAL");
        btnCuidadoP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCuidadoPActionPerformed(evt);
            }
        });

        btnDeudas.setBackground(new java.awt.Color(255, 51, 255));
        btnDeudas.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        btnDeudas.setText("DEUDAS");
        btnDeudas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeudasActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI Historic", 0, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Categorizemos tus gastos");

        btnCerrar3.setBackground(new java.awt.Color(204, 0, 0));
        btnCerrar3.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        btnCerrar3.setForeground(new java.awt.Color(0, 0, 0));
        btnCerrar3.setText("X");
        btnCerrar3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCerrar3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(146, 146, 146)
                        .addComponent(jLabel1))
                    .addComponent(jLabel2)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                            .addGap(6, 6, 6)
                            .addComponent(btnSalud, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(btnEducacion, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(btnAhorro)
                            .addGap(18, 18, 18)
                            .addComponent(btnCuidadoP)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnDeudas))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                            .addComponent(btnComida)
                            .addGap(12, 12, 12)
                            .addComponent(btnEntretenimiento, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(btnDeporte)
                            .addGap(18, 18, 18)
                            .addComponent(btnCamping)
                            .addGap(18, 18, 18)
                            .addComponent(btnMuebles)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(260, 260, 260)
                        .addComponent(btnCerrar, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(30, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(btnCerrar3, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addComponent(btnCerrar3)
                .addGap(9, 9, 9)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnComida, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnCamping, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnDeporte, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnMuebles, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnEntretenimiento, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnEducacion, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSalud, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAhorro, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnCuidadoP, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnDeudas, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                .addComponent(btnCerrar)
                .addGap(18, 18, 18))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnComidaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnComidaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnComidaActionPerformed

    private void btnCampingActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCampingActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnCampingActionPerformed

    private void btnEntretenimientoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEntretenimientoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnEntretenimientoActionPerformed

    private void btnDeporteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeporteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnDeporteActionPerformed

    private void btnMueblesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMueblesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnMueblesActionPerformed

    private void btnSaludActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaludActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnSaludActionPerformed

    private void btnEducacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEducacionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnEducacionActionPerformed

    private void btnAhorroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAhorroActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnAhorroActionPerformed

    private void btnCuidadoPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCuidadoPActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnCuidadoPActionPerformed

    private void btnDeudasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeudasActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnDeudasActionPerformed

    private void btnCerrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrarActionPerformed
        
    }//GEN-LAST:event_btnCerrarActionPerformed

    private void btnCerrar3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCerrar3ActionPerformed
        this.setVisible(false);
    }//GEN-LAST:event_btnCerrar3ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton btnAhorro;
    public javax.swing.JButton btnCamping;
    public javax.swing.JButton btnCerrar;
    public javax.swing.JButton btnCerrar1;
    public javax.swing.JButton btnCerrar2;
    public javax.swing.JButton btnCerrar3;
    public javax.swing.JButton btnComida;
    public javax.swing.JButton btnCuidadoP;
    public javax.swing.JButton btnDeporte;
    public javax.swing.JButton btnDeudas;
    public javax.swing.JButton btnEducacion;
    public javax.swing.JButton btnEntretenimiento;
    public javax.swing.JButton btnMuebles;
    public javax.swing.JButton btnSalud;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
