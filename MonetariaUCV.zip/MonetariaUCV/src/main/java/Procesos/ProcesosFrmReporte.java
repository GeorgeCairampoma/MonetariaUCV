
package Procesos;

import Vista.frmReporte;

public class ProcesosFrmReporte {


public static void Presentacion(frmReporte f1){
    f1.setTitle("Categorias");    
    f1.setVisible(true);
}    
    
public static void Apagar(frmReporte f1){
    f1.setVisible(false);
} 
}


