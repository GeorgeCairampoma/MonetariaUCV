package Procesos;
import Vista.*;
/**
 *
 * @author George Cairampoma Hernandez
 */
public class ProcesosFrmCategorias {

public static void Presentacion(frmCategorias f1){
    f1.setTitle("Categorias");    
    f1.setVisible(true);
}    
    
public static void Apagar(frmCategorias f1){
    f1.setVisible(false);
} 
}

