package Formatos;
import java.awt.Dimension;
import javax.swing.JInternalFrame;
import javax.swing.JDesktopPane;

public class CentrarForma {
        
    public static void CPanel(JDesktopPane pan,JInternalFrame inf, int i){
        Dimension desktopSize = pan.getSize();
        Dimension jifSize = inf.getSize();

        switch (i){
            case 1: 
                        inf.setLocation((desktopSize.width - jifSize.width)/2-220,
                         (desktopSize.height - jifSize.height)/2-20);
                        break;
            case 2:
                        inf.setLocation((desktopSize.width - jifSize.width)/2,
                         (desktopSize.height - jifSize.height)/2+0);
                        break;
            case 3:
                        inf.setLocation((desktopSize.width - jifSize.width)/2+450,
                         (desktopSize.height - jifSize.height)/2+0);
                        break;
        }
    }
}

