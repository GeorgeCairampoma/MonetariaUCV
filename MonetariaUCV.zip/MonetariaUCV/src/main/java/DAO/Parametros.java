package DAO;

public interface Parametros {    
    String DRIVER = "com.mysql.cj.jdbc.Driver";
    String RUTA = "jdbc:mysql://localhost:3309/monetaria"; 
    String USUARIO = "root";
    String CLAVE = "";    
}

