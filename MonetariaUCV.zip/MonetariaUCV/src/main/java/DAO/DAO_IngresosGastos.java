package DAO;

import java.sql.CallableStatement;
import java.sql.SQLException;

public class DAO_IngresosGastos extends ConectarBD {

    public DAO_IngresosGastos() {
    }

    // Método para guardar ingresos y gastos utilizando un procedimiento almacenado
public boolean guardarIngresosGastos(double ingresos, double gastos, int idUsuario) {
    try {
        // Obtener los ingresos y gastos actuales del usuario
        double[] ingresosYGastosActuales = obtenerIngresosYGastos(idUsuario);
        double ingresosActuales = ingresosYGastosActuales[0];
        double gastosActuales = ingresosYGastosActuales[1];

        if (ingresosActuales != 0 || gastosActuales != 0) {
            // Si ya existen datos, modificarlos en lugar de insertar nuevos
            return modificarIngresosGastos(idUsuario, ingresos, gastos, idUsuario);
        } else {
            // Si no hay datos existentes, guardar los nuevos ingresos y gastos
            CallableStatement cs = conexion.prepareCall("{call GuardarIngresosGastos(?, ?, ?, ?)}");
            cs.setDouble(1, ingresos);
            cs.setDouble(2, gastos);
            cs.setInt(3, idUsuario);
            cs.registerOutParameter(4, java.sql.Types.BOOLEAN);
            cs.execute();
            return cs.getBoolean(4); // Si la operación fue exitosa, retorna true
        }
    } catch (SQLException e) {
        e.printStackTrace();
        return false;
    }
}
    // Método para modificar ingresos y gastos utilizando un procedimiento almacenado
    public boolean modificarIngresosGastos(int id, double nuevosIngresos, double nuevosGastos, int idUsuario) {
        try {
            CallableStatement cs = conexion.prepareCall("{call ModificarIngresosGastos(?, ?, ?, ?, ?)}");
            cs.setInt(1, id);
            cs.setDouble(2, nuevosIngresos);
            cs.setDouble(3, nuevosGastos);
            cs.setInt(4, idUsuario);
            cs.registerOutParameter(5, java.sql.Types.BOOLEAN);
            cs.execute();
            return cs.getBoolean(5); // Si la operación fue exitosa, retorna true
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Método para obtener ingresos y gastos utilizando un procedimiento almacenado
    public double[] obtenerIngresosYGastos(int idUsuario) {
        double[] ingresosYGastos = new double[2];
        try {
            CallableStatement cs = conexion.prepareCall("{call ObtenerIngresosYGastos(?, ?, ?)}");
            cs.setInt(1, idUsuario);
            cs.registerOutParameter(2, java.sql.Types.DECIMAL);
            cs.registerOutParameter(3, java.sql.Types.DECIMAL);
            cs.execute();
            ingresosYGastos[0] = cs.getDouble(2);
            ingresosYGastos[1] = cs.getDouble(3);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return ingresosYGastos;
    }
}
